from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from . import models

table_mapper = {
    "post_data": models.Post,
    "author_data": models.Author,
}

class Database:

    def __init__(self, db_url):
        engine = create_engine(db_url)
        models.Base.metadata.create_all(bind=engine)
        self.maker = sessionmaker(bind=engine)

    def get_or_create(self, session, model, uniq_field, uniq_value, **data):
        db_data = session.query(model).filter(uniq_field == uniq_value).first()
        if not db_data:
            db_data= model(**data)
            session.add(db_data)
            try:
                session.commmit()
            except Exception as Exc:
                print(Exc)
                session.rollback()
        return db_data

    def get_or_create_comments(self, session, data: list) -> list:
        result = []
        if data:
            for comment in data:
                comment_author = self.get_or_create(
                    session,
                    models.Author,
                    models.Author.url,
                    comment["comment"]["user"]["url"],
                    name=comment["comment"]["user"]["full_name"],
                    url=comment["comment"]["user"]["url"],
                )
                db_comment = self.get_or_create(
                    session,
                    models.Comment,
                    models.Comment.id,
                    comment["comment"]["id"],
                    **comment["comment"],
                    author=comment_author,
                )

                result.append(db_comment)
                result.extend(
                    self.get_or_create_comments(session, comment["comment"]["children"])
                )

        return result

    def create_post(self, data):
        session = self.maker()
        comments = self.get_or_create_comments(session, data["comments_data"])
        author = self.get_or_create(
            session,
            models.Author,
            models.Author.url,
            data["author_data"]["url"],
            **data["author_data"],
        )
        tags = map(
            lambda tag_data: self.get_or_create(
                session, models.Tag, models.Tag.url, tag_data["url"], **tag_data
            ),
            data["tags_data"],
        )
        post = self.get_or_create(
            session,
            models.Post,
            models.Post.id,
            data["post_data"]["id"],
            **data["post_data"],
            author=author,
            # img_url=data["post_data"]["img_url"],
            # date=data["post_data"]["date"],
        )
        post.tags.extend(tags)
        print(1)
        try:
            post.comments.extend(comments)
        except:
            print(2)

        session.add(post)

        try:
            session.commit()
        except Exception as exc:
            print(exc)
            session.rollback()
        finally:
            session.close()
        print(1)